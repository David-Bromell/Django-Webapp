from django.apps import AppConfig

#App config for CityHopper to find the App
class CityhopperappConfig(AppConfig):
    name = 'CityHopperApp'
